#zimiao_red_szzx
use jetson_nano+python3.6+numpy1.14+opencv3.4.15.55
